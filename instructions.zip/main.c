
#include <stdio.h>

int main()
{
    int a=22;
    int b=a;
    int c=b+1;
    int d=1,e;
    printf("%d\n%d\n%d\n%d",a,b,c,d);
    

    return 0;
}
